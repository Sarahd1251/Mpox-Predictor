from website import ISE2
#from MODEL import CapstoneProject (Kris's code)

def main():
    CapstoneProject()
    ISE2()
main()
