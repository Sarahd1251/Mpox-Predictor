# Mpox-Predictor

***

## Project Description
This goal for this website is to use machine learning to predict and forecast Mpox cases by region, and then use interactive tools to display those outputs.

## Current User Interface Design (2/21/23)
![image2](https://user-images.githubusercontent.com/60261890/220718302-12e0393e-6fbc-49b8-a85b-252d57fb6f68.png)
